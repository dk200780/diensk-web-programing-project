// Default Breathing Patterns
let PATTERNS = {
  box: [
    { text: 'Inhale', duration: 4, scale: 2 },
    { text: 'Hold', duration: 4, scale: 2 },
    { text: 'Exhale', duration: 4, scale: 1 },
    { text: 'Hold', duration: 4, scale: 1 }
  ],
  relax: [
    { text: 'Inhale', duration: 4, scale: 2 },
    { text: 'Hold', duration: 7, scale: 2 },
    { text: 'Exhale', duration: 8, scale: 1 }
  ],
  calm: [
    { text: 'Inhale', duration: 4, scale: 2 },
    { text: 'Exhale', duration: 4, scale: 1 }
  ]
};

// Application State
let currentPattern = PATTERNS.box;
let phaseIndex = 0;
let timeLeft = 0;
let timerInterval = null;
let isRunning = false;
let sessionStartTime = null;

// Speech & Audio Setup
const synth = window.speechSynthesis;
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
let ambientOscillator = null;

// DOM Elements
const circle = document.getElementById('breathCircle');
const instructionText = document.getElementById('instructionText');
const timerText = document.getElementById('timerText');
const patternSelect = document.getElementById('patternSelect');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const voiceToggle = document.getElementById('voiceToggle');
const ambientToggle = document.getElementById('ambientToggle');

// Tab Navigation Logic
document.querySelectorAll('.tab-btn').forEach(button => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn, .tab-content').forEach(el => el.classList.remove('active'));
    button.classList.add('active');
    document.getElementById(`tab-${button.dataset.tab}`).classList.add('active');
  });
});

// Voice Cue Feature (Web Speech API)
function speak(text) {
  if (!voiceToggle.checked || !synth) return;
  synth.cancel(); // Stop current speech
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 0.85;
  synth.speak(utterance);
}

// Ambient Binaural Audio Generator (Web Audio API)
function toggleAmbientSound(enable) {
  if (enable) {
    ambientOscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    ambientOscillator.type = 'sine';
    ambientOscillator.frequency.setValueAtTime(108, audioCtx.currentTime); // Relaxing 108Hz drone
    gainNode.gain.setValueAtTime(0.03, audioCtx.currentTime); // Low background volume
    ambientOscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    ambientOscillator.start();
  } else if (ambientOscillator) {
    ambientOscillator.stop();
    ambientOscillator = null;
  }
}

ambientToggle.addEventListener('change', (e) => toggleAmbientSound(e.target.checked));

// Particle Visualizer Engine
const canvas = document.getElementById('particleCanvas');
const ctx = canvas.getContext('2d');
let particles = [];

class Particle {
  constructor() {
    this.reset();
  }
  reset() {
    this.x = canvas.width / 2;
    this.y = canvas.height / 2;
    this.angle = Math.random() * Math.PI * 2;
    this.speed = Math.random() * 1.5 + 0.5;
    this.radius = Math.random() * 3 + 1;
    this.alpha = 1;
  }
  update(isExpanding) {
    const dir = isExpanding ? 1 : -0.5;
    this.x += Math.cos(this.angle) * this.speed * dir;
    this.y += Math.sin(this.angle) * this.speed * dir;
    this.alpha -= 0.008;
    if (this.alpha <= 0) this.reset();
  }
  draw() {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(56, 189, 248, ${this.alpha})`;
    ctx.fill();
  }
}

for (let i = 0; i < 40; i++) particles.push(new Particle());

function renderParticles() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const isExpanding = currentPattern[phaseIndex]?.scale > 1;
  particles.forEach(p => {
    p.update(isExpanding);
    p.draw();
  });
  if (isRunning) requestAnimationFrame(renderParticles);
}

// Core Breathing Logic
function updateCircleScale(scale, duration) {
  circle.style.transition = `transform ${duration}s ease-in-out`;
  circle.style.setProperty('--circle-scale', scale);
}

function runBreathingCycle() {
  if (!isRunning) return;

  const phase = currentPattern[phaseIndex];
  instructionText.textContent = phase.text;
  timeLeft = phase.duration;
  timerText.textContent = timeLeft;

  speak(phase.text);
  updateCircleScale(phase.scale, phase.duration);

  timerInterval = setInterval(() => {
    timeLeft--;
    if (timeLeft > 0) {
      timerText.textContent = timeLeft;
    } else {
      clearInterval(timerInterval);
      phaseIndex = (phaseIndex + 1) % currentPattern.length;
      runBreathingCycle();
    }
  }, 1000);
}

// Custom Pattern Builder
document.getElementById('saveCustomBtn').addEventListener('click', () => {
  const inhale = parseInt(document.getElementById('customInhale').value) || 4;
  const holdIn = parseInt(document.getElementById('customHoldIn').value) || 0;
  const exhale = parseInt(document.getElementById('customExhale').value) || 4;
  const holdOut = parseInt(document.getElementById('customHoldOut').value) || 0;

  PATTERNS.custom = [{ text: 'Inhale', duration: inhale, scale: 2 }];
  if (holdIn > 0) PATTERNS.custom.push({ text: 'Hold', duration: holdIn, scale: 2 });
  PATTERNS.custom.push({ text: 'Exhale', duration: exhale, scale: 1 });
  if (holdOut > 0) PATTERNS.custom.push({ text: 'Hold', duration: holdOut, scale: 1 });

  if (!document.querySelector('option[value="custom"]')) {
    const opt = document.createElement('option');
    opt.value = 'custom';
    opt.textContent = 'Custom Pattern';
    patternSelect.appendChild(opt);
  }
  patternSelect.value = 'custom';
  alert('Custom pattern saved and selected!');
});

// Analytics & Persistence (LocalStorage)
function updateStats(sessionSeconds) {
  const totalSessions = parseInt(localStorage.getItem('totalSessions') || '0') + 1;
  const totalMinutes = parseFloat(localStorage.getItem('totalMinutes') || '0') + (sessionSeconds / 60);
  
  const lastDate = localStorage.getItem('lastSessionDate');
  const today = new Date().toDateString();
  let streak = parseInt(localStorage.getItem('streakCount') || '0');

  if (lastDate !== today) {
    streak = (lastDate === new Date(Date.now() - 86400000).toDateString()) ? streak + 1 : 1;
  }

  localStorage.setItem('totalSessions', totalSessions);
  localStorage.setItem('totalMinutes', totalMinutes.toFixed(1));
  localStorage.setItem('streakCount', streak);
  localStorage.setItem('lastSessionDate', today);

  loadStats();
}

function loadStats() {
  document.getElementById('totalSessions').textContent = localStorage.getItem('totalSessions') || '0';
  document.getElementById('totalMinutes').textContent = localStorage.getItem('totalMinutes') || '0';
  document.getElementById('streakCount').textContent = localStorage.getItem('streakCount') || '0';
}

// Event Listeners
startBtn.addEventListener('click', () => {
  if (audioCtx.state === 'suspended') audioCtx.resume();
  isRunning = true;
  phaseIndex = 0;
  sessionStartTime = Date.now();

  startBtn.disabled = true;
  stopBtn.disabled = false;
  patternSelect.disabled = true;

  currentPattern = PATTERNS[patternSelect.value];
  runBreathingCycle();
  renderParticles();
});

stopBtn.addEventListener('click', () => {
  isRunning = false;
  clearInterval(timerInterval);
  
  if (sessionStartTime) {
    const elapsedSeconds = Math.round((Date.now() - sessionStartTime) / 1000);
    if (elapsedSeconds >= 10) updateStats(elapsedSeconds);
  }

  instructionText.textContent = 'Ready';
  timerText.textContent = '';
  updateCircleScale(1, 0.5);
  
  startBtn.disabled = false;
  stopBtn.disabled = true;
  patternSelect.disabled = false;
});

// Initial Load
loadStats();
